package com.WebservicesExample.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.WebservicesExample.beans.Doctors;
import com.WebservicesExample.repository.DoctorDao;

@RestController
public class DoctorsController {
	
	@Autowired
    DoctorDao doctorDao;
	
	@GetMapping("retriveDoctorList")
	public List<Doctors> getDoctorNames(){
		List<Doctors> list= (List<Doctors>) doctorDao.findAll();
		return list;
	}
}
