package com.WebservicesExample.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.WebservicesExample.beans.Doctors;
@Repository
public interface DoctorDao extends CrudRepository<Doctors,Integer>{
	
}
