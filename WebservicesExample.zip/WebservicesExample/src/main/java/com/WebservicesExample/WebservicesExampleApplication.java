package com.WebservicesExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication(scanBasePackages = {"com.WebservicesExample","com.WebservicesExample.beans","com.WebservicesExample.controllers","com.WebservicesExample.repository"})
/*@SpringBootApplication
@ComponentScan({"com.WebservicesExample","com.WebservicesExample.beans","com.WebservicesExample.controllers","com.WebservicesExample.repository"})*/
public class WebservicesExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebservicesExampleApplication.class, args);
	}
}
